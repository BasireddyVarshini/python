# Flask Web Application

A simple Flask web application with:

- Home, About, and Contact pages
- Bootstrap for styling
- Jinja2 templating

## 🛠 How to Run

1. Create a virtual environment and install dependencies:

```bash
pip install -r requirements.txt
```

2. Run the app:

```bash
python app.py
```

3. Open your browser and go to:

```
http://127.0.0.1:5000/
```