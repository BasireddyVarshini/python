import argparse
import json
import os

TASKS_FILE = "todo.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, 'w') as f:
            json.dump([], f)
    with open(TASKS_FILE, 'r') as f:
        return json.load(f)

def save_tasks(tasks):
    with open(TASKS_FILE, 'w') as f:
        json.dump(tasks, f, indent=4)

def add_task(description):
    tasks = load_tasks()
    tasks.append({"task": description, "done": False})
    save_tasks(tasks)
    print(f"✅ Task added: {description}")

def list_tasks():
    tasks = load_tasks()
    if not tasks:
        print("📭 No tasks found.")
        return
    for idx, task in enumerate(tasks, start=1):
        status = "✔️" if task["done"] else "❌"
        print(f"{idx}. {task['task']} [{status}]")

def delete_task(index):
    tasks = load_tasks()
    try:
        removed = tasks.pop(index - 1)
        save_tasks(tasks)
        print(f"🗑️ Task deleted: {removed['task']}")
    except IndexError:
        print("⚠️ Invalid task number.")

def mark_done(index):
    tasks = load_tasks()
    try:
        tasks[index - 1]["done"] = True
        save_tasks(tasks)
        print(f"✅ Task marked as done: {tasks[index - 1]['task']}")
    except IndexError:
        print("⚠️ Invalid task number.")

def main():
    parser = argparse.ArgumentParser(description="Simple To-Do CLI Tool")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("list", help="List all tasks")

    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("description", help="Task description")

    del_parser = subparsers.add_parser("delete", help="Delete a task")
    del_parser.add_argument("index", type=int, help="Task number to delete")

    done_parser = subparsers.add_parser("done", help="Mark task as done")
    done_parser.add_argument("index", type=int, help="Task number to mark as done")

    args = parser.parse_args()

    if args.command == "add":
        add_task(args.description)
    elif args.command == "list":
        list_tasks()
    elif args.command == "delete":
        delete_task(args.index)
    elif args.command == "done":
        mark_done(args.index)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()