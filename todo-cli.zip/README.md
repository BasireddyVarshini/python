# ✅ To-Do List CLI Tool

A simple command-line to-do list manager built in Python using the `argparse` library.

## Features
- Add tasks
- List tasks
- Delete tasks
- Mark tasks as done

## Usage

```bash
# Add a task
python todo.py add "Read a book"

# List all tasks
python todo.py list

# Mark a task as done
python todo.py done 1

# Delete a task
python todo.py delete 2
```

## How it works
- Tasks are saved in a JSON file `todo.json` in the same folder.
- Uses only standard Python libraries.

## Setup
No installation required. Just run:

```bash
python todo.py
```